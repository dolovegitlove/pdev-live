Desktop App Binaries

These files are downloaded automatically during installation from:
https://vyxenai.com/pdev/releases/

Files:
- PDev-Live-1.0.0.dmg (macOS)
- PDev-Live-1.0.0.exe (Windows)
- PDev-Live-1.0.0.deb (Linux)

You don't need to download them manually.
The installer handles this automatically.
